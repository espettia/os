#include <stdio.h>

int main() {
	char cadena[]="12: 5 6";
	int n1,n2,n3;
	
	sscanf(cadena,"%d: %d %d",&n1,&n2,&n3);
    printf("Los números son:%d,%d,%d\n",n1,n2,n3);
    return 0;
}    
